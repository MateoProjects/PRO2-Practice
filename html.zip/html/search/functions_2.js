var searchData=
[
  ['cjt_5findividus',['Cjt_individus',['../class_cjt__individus.html#ace12a900a02d3b12c8067c7867618c50',1,'Cjt_individus::Cjt_individus()'],['../class_cjt__individus.html#a34fc972178df2f153cd7566746fec5c7',1,'Cjt_individus::Cjt_individus(int n)']]],
  ['cjt_5ftrets',['Cjt_trets',['../class_cjt__trets.html#a0f3d29b433ebfa6d9680e1ee0f39279b',1,'Cjt_trets']]],
  ['consultar_5findividus',['consultar_individus',['../class_cjt__individus.html#ab4c2050572964290f9174e5a35c62e93',1,'Cjt_individus']]],
  ['consultar_5ftret',['consultar_tret',['../class_cjt__trets.html#a3d6af3339dc026b5bd85ad0421fc8335',1,'Cjt_trets::consultar_tret()'],['../class_individu.html#ada0323e42244b25c8864a4f5e4b6f725',1,'Individu::consultar_tret()']]],
  ['cromosomes',['cromosomes',['../class_individu.html#a1a21a3a81029aa3bfcab85e44f143f9d',1,'Individu']]]
];
