var searchData=
[
  ['individus',['individus',['../struct_cjt__trets_1_1tretstr.html#aa5653ef7b63a8e68ddd53abdee41ad80',1,'Cjt_trets::tretstr']]]
];
