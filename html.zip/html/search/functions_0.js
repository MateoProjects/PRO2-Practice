var searchData=
[
  ['afegir_5ftret',['afegir_tret',['../class_cjt__individus.html#a65a4dd6cd58263f99aa5dc14eb2b136d',1,'Cjt_individus::afegir_tret()'],['../class_cjt__trets.html#af9595412e48426d29af4350047fa263c',1,'Cjt_trets::afegir_tret()'],['../class_individu.html#a83881aba105a3b2c68a704c19ff6194d',1,'Individu::afegir_tret()']]],
  ['agafar_5findividu',['agafar_individu',['../class_cjt__individus.html#a8df4f6b881a86e171e5fbcfbde7f3696',1,'Cjt_individus']]],
  ['arbre_5fnou',['arbre_nou',['../class_cjt__individus.html#a5691f845170d1b71d64ee9bf319afc2f',1,'Cjt_individus']]]
];
