var searchData=
[
  ['trets',['trets',['../class_cjt__trets.html#a68d3d3dbfae9392cc211b3bc9a49f047',1,'Cjt_trets::trets()'],['../class_individu.html#a0ac8e4f21a7d491e6c8b90f267065bca',1,'Individu::trets()']]]
];
