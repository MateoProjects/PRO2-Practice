var searchData=
[
  ['trets_5finici',['trets_inici',['../class_cjt__trets.html#a5da3848168e16b7c7e4e52cbe74854e3',1,'Cjt_trets']]]
];
