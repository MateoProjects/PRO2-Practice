var searchData=
[
  ['trets',['trets',['../class_cjt__trets.html#a68d3d3dbfae9392cc211b3bc9a49f047',1,'Cjt_trets::trets()'],['../class_individu.html#a0ac8e4f21a7d491e6c8b90f267065bca',1,'Individu::trets()']]],
  ['trets_5finici',['trets_inici',['../class_cjt__trets.html#a5da3848168e16b7c7e4e52cbe74854e3',1,'Cjt_trets']]],
  ['tretstr',['tretstr',['../struct_cjt__trets_1_1tretstr.html',1,'Cjt_trets']]]
];
