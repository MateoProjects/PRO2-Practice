var searchData=
[
  ['distribucio',['distribucio',['../class_cjt__individus.html#a13b4b806235ab7eb6bc5073d5c1bc67c',1,'Cjt_individus']]]
];
