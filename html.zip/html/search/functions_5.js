var searchData=
[
  ['individu',['Individu',['../class_individu.html#ac35091404cfbf11946694806aefa9e7e',1,'Individu']]],
  ['interseccio_5ftret',['interseccio_tret',['../class_parcrom.html#a575474066aa8c5f589516c3be468ec71',1,'Parcrom']]]
];
